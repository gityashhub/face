import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Login from "./pages/Common/login";
import ForgotPassword from './components/Common/ForgotPassword';
import AdminDashboard from './pages/Admin/AdminDashboard';
import EmployeeManagement from './pages/Admin/EmployeeManagement';
import EmployeeDashboard from './pages/Employee/EmployeeDashboard';
import ProtectedRoute from './routes/ProtectedRoute';
import './App.css';
import AdminLeaveManagement from './pages/Admin/AdminLeaveManagement';
import AdminTaskManagement from './pages/Admin/AdminTaskManagement';
import EmployeeLeaveRequests from './pages/Employee/EmployeeLeaveRequests';
import EmployeeTasks from './pages/Employee/EmployeeTasks';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          {/* Auth Routes */}
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          
          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          } />
          <Route path="/admin/employees" element={
            <ProtectedRoute role="admin">
              <EmployeeManagement />
            </ProtectedRoute>
          } />
          <Route path="/admin/leaves" element={
            <ProtectedRoute role="admin">
              <AdminLeaveManagement />
            </ProtectedRoute>
          } />
           <Route path="/admin/tasks" element={
            <ProtectedRoute role="admin">
              <AdminTaskManagement/>
            </ProtectedRoute>
          } />
          
          {/* Employee Routes */}
          <Route path="/employee/dashboard" element={
            <ProtectedRoute role="employee">
              <EmployeeDashboard />
            </ProtectedRoute>
          } />
           <Route path="/employee/leaves" element={
            <ProtectedRoute role="employee">
              <EmployeeLeaveRequests />
            </ProtectedRoute>
          } />
           <Route path="/employee/tasks" element={
            <ProtectedRoute role="employee">
              <EmployeeTasks />
            </ProtectedRoute>
          } />
        </Routes>
        <Toaster position="top-right" />
      </Router>
    </div>
  );
}

export default App;