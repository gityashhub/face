import api from './api';

export const taskService = {
  // Get all tasks with filters
  getTasks: async (params = {}) => {
    try {
      const response = await api.get('/tasks', { params });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get tasks' };
    }
  },

  // Get task by ID
  getTaskById: async (taskId) => {
    try {
      const response = await api.get(`/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get task' };
    }
  },

  // Create new task (Admin only)
  createTask: async (taskData) => {
    try {
      const response = await api.post('/tasks', taskData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to create task' };
    }
  },

  // Update task
  updateTask: async (taskId, taskData) => {
    try {
      const response = await api.put(`/tasks/${taskId}`, taskData);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update task' };
    }
  },

  // Delete task (Admin only)
  deleteTask: async (taskId) => {
    try {
      const response = await api.delete(`/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to delete task' };
    }
  },

  // Add comment to task
  addComment: async (taskId, text) => {
    try {
      const response = await api.post(`/tasks/${taskId}/comments`, { text });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to add comment' };
    }
  },

  // Update task progress
  updateProgress: async (taskId, progress) => {
    try {
      const response = await api.put(`/tasks/${taskId}/progress`, { progress });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to update progress' };
    }
  },

  // Change task status
  changeStatus: async (taskId, status) => {
    try {
      const response = await api.put(`/tasks/${taskId}/status`, { status });
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to change status' };
    }
  },

  // Toggle subtask
  toggleSubtask: async (taskId, subtaskId) => {
    try {
      const response = await api.put(`/tasks/${taskId}/subtasks/${subtaskId}`);
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to toggle subtask' };
    }
  },

  // Get task statistics
  getTaskStats: async () => {
    try {
      const response = await api.get('/tasks/stats');
      return response.data;
    } catch (error) {
      throw error.response?.data || { message: 'Failed to get task stats' };
    }
  }
};