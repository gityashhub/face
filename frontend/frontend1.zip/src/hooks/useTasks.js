import { useState, useEffect } from 'react';
import { taskService } from '../services/taskService';
import toast from 'react-hot-toast';

export const useTasks = (initialFilters = {}) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState(initialFilters);
  const [stats, setStats] = useState(null);

  // Fetch tasks
  const fetchTasks = async (filterParams = filters) => {
    try {
      setLoading(true);
      const response = await taskService.getTasks(filterParams);
      setTasks(response.tasks || []);
      setError(null);
    } catch (error) {
      setError(error.message);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  // Fetch task stats
  const fetchStats = async () => {
    try {
      const response = await taskService.getTaskStats();
      setStats(response.stats);
    } catch (error) {
      console.error('Failed to fetch task stats:', error);
    }
  };

  // Create task
  const createTask = async (taskData) => {
    try {
      const response = await taskService.createTask(taskData);
      setTasks(prev => [response.task, ...prev]);
      toast.success('Task created successfully!');
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Update task
  const updateTask = async (taskId, taskData) => {
    try {
      const response = await taskService.updateTask(taskId, taskData);
      setTasks(prev => prev.map(task => 
        task._id === taskId ? response.task : task
      ));
      toast.success('Task updated successfully!');
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Delete task
  const deleteTask = async (taskId) => {
    try {
      await taskService.deleteTask(taskId);
      setTasks(prev => prev.filter(task => task._id !== taskId));
      toast.success('Task deleted successfully!');
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Update task progress
  const updateProgress = async (taskId, progress) => {
    try {
      const response = await taskService.updateProgress(taskId, progress);
      setTasks(prev => prev.map(task => 
        task._id === taskId ? response.task : task
      ));
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Change task status
  const changeStatus = async (taskId, status) => {
    try {
      const response = await taskService.changeStatus(taskId, status);
      setTasks(prev => prev.map(task => 
        task._id === taskId ? response.task : task
      ));
      toast.success(`Task status updated to ${status}!`);
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Add comment
  const addComment = async (taskId, text) => {
    try {
      const response = await taskService.addComment(taskId, text);
      setTasks(prev => prev.map(task => 
        task._id === taskId ? response.task : task
      ));
      toast.success('Comment added!');
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  // Toggle subtask
  const toggleSubtask = async (taskId, subtaskId) => {
    try {
      const response = await taskService.toggleSubtask(taskId, subtaskId);
      setTasks(prev => prev.map(task => 
        task._id === taskId ? response.task : task
      ));
      return response;
    } catch (error) {
      toast.error(error.message);
      throw error;
    }
  };

  useEffect(() => {
    fetchTasks();
    fetchStats();
  }, [filters]);

  return {
    tasks,
    loading,
    error,
    stats,
    filters,
    setFilters,
    fetchTasks,
    fetchStats,
    createTask,
    updateTask,
    deleteTask,
    updateProgress,
    changeStatus,
    addComment,
    toggleSubtask
  };
};
