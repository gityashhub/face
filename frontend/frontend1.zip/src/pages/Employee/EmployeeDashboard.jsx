import React, { useState, useEffect } from 'react';
import EmployeeLayout from '../../components/Employee/EmployeeLayout/EmployeeLayout';
import { 
  User, Clock, Calendar, DollarSign, CheckCircle, AlertCircle, MapPin, Bell, Award, Target, TrendingUp, FileText
} from 'lucide-react';
import toast from 'react-hot-toast';
import { employeeAPI, authAPI } from '../../utils/api'; // Use your existing API structure

const EmployeeDashboard = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [attendanceMarked, setAttendanceMarked] = useState(false);
  const [location, setLocation] = useState(null);
  const [employeeData, setEmployeeData] = useState(null);
  const [dashboardStats, setDashboardStats] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch employee profile and create dashboard data
  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        setLoading(true);
        
        // Try the updated getMyProfile method first
        let profileResponse;
        try {
          profileResponse = await authAPI.getMyProfile(); // NEW: Use authAPI.getMyProfile()
        } catch (error) {
          // Fallback to employeeAPI if authAPI fails
          console.warn('authAPI.getMyProfile() failed, trying employeeAPI.getMyProfile()');
          profileResponse = await employeeAPI.getMyProfile();
        }
        
        console.log('Employee profile response:', profileResponse);

        if (profileResponse.data && profileResponse.data.success) {
          const employee = profileResponse.data.data;
          setEmployeeData(employee);

          // Create dashboard stats from employee data
          const stats = [
            { 
              title: 'Days Present', 
              value: '22', // You can calculate this from attendance data later
              subtitle: 'This Month', 
              icon: CheckCircle, 
              color: 'from-green-500 to-green-600', 
              change: '+2 from last month' 
            },
            { 
              title: 'Leave Balance', 
              value: employee.leaveBalance?.remaining?.toString() || '30', 
              subtitle: 'Days Remaining', 
              icon: Calendar, 
              color: 'from-blue-500 to-blue-600', 
              change: `${employee.leaveBalance?.total || 30} total allocated`
            },
            { 
              title: 'Current Salary', 
              value: `₹${employee.salaryInfo?.basicSalary?.toLocaleString() || '60,000'}`, 
              subtitle: 'Basic Salary', 
              icon: DollarSign, 
              color: 'from-purple-500 to-purple-600', 
              change: 'Monthly' 
            },
            { 
              title: 'Years of Service', 
              value: employee.yearsOfService?.toString() || '0', 
              subtitle: 'Years', 
              icon: Target, 
              color: 'from-pink-500 to-pink-600', 
              change: `Since ${employee.workInfo?.joiningDate ? new Date(employee.workInfo.joiningDate).getFullYear() : 'N/A'}` 
            }
          ];
          setDashboardStats(stats);
        } else {
          console.error('Failed to fetch employee profile:', profileResponse);
          toast.error('Unable to load your profile data');
          setDefaultStats();
        }

      } catch (error) {
        console.error('Error fetching employee data:', error);
        
        // Better error handling
        if (error.response?.status === 401) {
          toast.error('Session expired. Please login again.');
          // The interceptor will handle the redirect
        } else if (error.response?.status === 403) {
          toast.error('Access denied. Please contact HR.');
        } else if (error.response?.status === 404) {
          toast.error('Employee profile not found. Please contact HR.');
        } else if (error.response?.data?.message) {
          toast.error(error.response.data.message);
        } else if (error.message) {
          toast.error(error.message);
        } else {
          toast.error('Unable to load dashboard data. Please try again.');
        }
        
        setDefaultStats();
      } finally {
        setLoading(false);
      }
    };

    fetchEmployeeData();
  }, []);

  const setDefaultStats = () => {
    setDashboardStats([
      { title: 'Days Present', value: '22', subtitle: 'This Month', icon: CheckCircle, color: 'from-green-500 to-green-600', change: '+2 from last month' },
      { title: 'Leave Balance', value: '30', subtitle: 'Days Remaining', icon: Calendar, color: 'from-blue-500 to-blue-600', change: '30 total allocated' },
      { title: 'Current Salary', value: '₹60,000', subtitle: 'Basic Salary', icon: DollarSign, color: 'from-purple-500 to-purple-600', change: 'Monthly' },
      { title: 'Years of Service', value: '0', subtitle: 'Years', icon: Target, color: 'from-pink-500 to-pink-600', change: 'New Employee' }
    ]);
  };

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const markAttendance = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
          setAttendanceMarked(true);
          toast.success('Attendance marked successfully!');
        },
        (error) => {
          toast.error('Location access denied. Please enable location services.');
        }
      );
    } else {
      toast.error('Geolocation is not supported by this browser.');
    }
  };

  // Mock data for notices and tasks (you can replace these with real API calls later)
  const recentNotices = [
    {
      id: 1,
      title: "Company Holiday Announcement",
      message: "Office will be closed on October 15th for Diwali festival.",
      date: "2024-10-10",
      priority: "High"
    },
    {
      id: 2,
      title: "New HR Policy Update",
      message: "Please review the updated attendance policy in the employee handbook.",
      date: "2024-10-08",
      priority: "Medium"
    },
    {
      id: 3,
      title: "Team Meeting Scheduled",
      message: "Monthly team sync meeting scheduled for tomorrow at 2 PM.",
      date: "2024-10-09",
      priority: "Medium"
    }
  ];

  const currentTasks = [
    {
      id: 1,
      title: "Complete Project Documentation",
      status: "In Progress",
      priority: "High",
      dueDate: "2024-10-15"
    },
    {
      id: 2,
      title: "Review Code Changes",
      status: "Pending",
      priority: "Medium",
      dueDate: "2024-10-12"
    },
    {
      id: 3,
      title: "Update System Requirements",
      status: "Completed",
      priority: "Low",
      dueDate: "2024-10-08"
    },
    {
      id: 4,
      title: "Client Meeting Preparation",
      status: "In Progress",
      priority: "High",
      dueDate: "2024-10-14"
    }
  ];

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'completed': case 'on track': return 'text-green-400 bg-green-400/20';
      case 'in progress': case 'nearly complete': return 'text-yellow-400 bg-yellow-400/20';
      case 'pending': case 'not started': return 'text-red-400 bg-red-400/20';
      default: return 'text-secondary-400 bg-secondary-400/20';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority.toLowerCase()) {
      case 'high': return 'text-red-400 bg-red-400/20';
      case 'medium': return 'text-yellow-400 bg-yellow-400/20';
      case 'low': return 'text-green-400 bg-green-400/20';
      default: return 'text-secondary-400 bg-secondary-400/20';
    }
  };

  if (loading) {
    return (
      <EmployeeLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-white">Loading your dashboard...</div>
        </div>
      </EmployeeLayout>
    );
  }

  // Handle case where profile couldn't be loaded but still show dashboard with defaults
  const displayName = employeeData?.personalInfo ? 
    `${employeeData.personalInfo.firstName} ${employeeData.personalInfo.lastName}` : 
    employeeData?.fullName || 'Employee';

  const displayPosition = employeeData?.workInfo?.position || 'Employee';
  const displayDepartment = employeeData?.workInfo?.department || 'General';
  const displayEmployeeId = employeeData?.employeeId || employeeData?.user?.employeeId || 'N/A';

  return (
    <EmployeeLayout employeeData={employeeData}>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-r from-neon-pink to-neon-purple rounded-2xl flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white mb-1">
                  Welcome, <span className="neon-text">{displayName}!</span>
                </h1>
                <p className="text-secondary-400">{displayPosition} • {displayDepartment}</p>
                <p className="text-sm text-neon-pink">Employee ID: {displayEmployeeId}</p>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 text-right">
              <p className="text-lg font-semibold text-white">
                {currentTime.toLocaleTimeString()}
              </p>
              <p className="text-secondary-400">
                {currentTime.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        {dashboardStats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {dashboardStats.map((stat, index) => (
              <div key={index} className="glass-morphism neon-border rounded-2xl p-6 hover-glow">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
                  <p className="text-secondary-400 text-sm mb-2">{stat.title}</p>
                  <p className="text-xs text-neon-pink">{stat.change}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Attendance Section */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Today's Attendance</h2>
            <Clock className="w-5 h-5 text-neon-pink" />
          </div>
          
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`w-4 h-4 rounded-full ${attendanceMarked ? 'bg-green-400' : 'bg-red-400'} animate-pulse`}></div>
              <div>
                <p className="text-white font-medium">
                  Status: <span className={attendanceMarked ? 'text-green-400' : 'text-red-400'}>
                    {attendanceMarked ? 'Present' : 'Not Marked'}
                  </span>
                </p>
                {attendanceMarked && (
                  <p className="text-sm text-secondary-400">
                    Marked at {currentTime.toLocaleTimeString()}
                  </p>
                )}
              </div>
            </div>
            
            {!attendanceMarked && (
              <button
                onClick={markAttendance}
                className="mt-4 md:mt-0 px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-purple text-white font-semibold rounded-lg hover-glow transition-all duration-300 flex items-center"
              >
                <MapPin className="w-4 h-4 mr-2" />
                Mark Attendance
              </button>
            )}
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Profile Summary */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Profile Summary</h2>
              <User className="w-5 h-5 text-neon-pink" />
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Employee ID</span>
                <span className="text-white font-medium">{displayEmployeeId}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Department</span>
                <span className="text-white font-medium">{displayDepartment}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Join Date</span>
                <span className="text-white font-medium">
                  {employeeData?.workInfo?.joiningDate ? 
                    new Date(employeeData.workInfo.joiningDate).toLocaleDateString() : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Email</span>
                <span className="text-white font-medium">{employeeData?.contactInfo?.personalEmail || employeeData?.user?.email || 'N/A'}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Phone</span>
                <span className="text-white font-medium">{employeeData?.contactInfo?.phone || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Latest Notices */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Latest Notices</h2>
              <Bell className="w-5 h-5 text-neon-purple" />
            </div>
            
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {recentNotices.map((notice) => (
                <div key={notice.id} className="p-4 border border-secondary-600 rounded-lg hover:border-neon-pink/30 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-white font-medium">{notice.title}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full ${getPriorityColor(notice.priority)}`}>
                      {notice.priority}
                    </span>
                  </div>
                  <p className="text-secondary-400 text-sm mb-2">{notice.message}</p>
                  <p className="text-xs text-neon-pink">{new Date(notice.date).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tasks Section */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Current Tasks</h2>
            <Target className="w-5 h-5 text-neon-pink" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentTasks.map((task) => (
              <div key={task.id} className="p-4 border border-secondary-600 rounded-lg hover:border-neon-pink/30 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-medium text-sm">{task.title}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(task.status)}`}>
                    {task.status}
                  </span>
                  <p className="text-xs text-secondary-400">Due: {new Date(task.dueDate).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Leave and Salary Info */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Leave Information */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Leave Information</h2>
              <Calendar className="w-5 h-5 text-neon-pink" />
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Total Leave</span>
                <span className="text-white font-medium">{employeeData?.leaveBalance?.total || 30} days</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Used Leave</span>
                <span className="text-white font-medium">{employeeData?.leaveBalance?.used || 0} days</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Remaining</span>
                <span className="text-neon-pink font-medium">{employeeData?.leaveBalance?.remaining || 30} days</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Pending Requests</span>
                <span className="text-yellow-400 font-medium">0 requests</span>
              </div>
            </div>
          </div>

          {/* Latest Salary Info */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Salary Information</h2>
              <DollarSign className="w-5 h-5 text-neon-purple" />
            </div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Basic Salary</span>
                <span className="text-white font-medium">
                  ₹{employeeData?.salaryInfo?.basicSalary?.toLocaleString() || '60,000'}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Gross Salary</span>
                <span className="text-neon-purple font-medium">
                  ₹{employeeData?.grossSalary?.toLocaleString() || '75,000'}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Employment Type</span>
                <span className="text-white font-medium">{employeeData?.workInfo?.employmentType || 'Full-time'}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary-800/30 rounded-lg">
                <span className="text-secondary-400">Work Location</span>
                <span className="text-white font-medium">{employeeData?.workInfo?.workLocation || 'Office'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <h2 className="text-xl font-bold text-white mb-6">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button 
              onClick={() => window.location.href = '/employee/leaves'}
              className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-pink/50 hover:bg-neon-pink/5 transition-all duration-300 group"
            >
              <Calendar className="w-8 h-8 text-secondary-400 group-hover:text-neon-pink mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">Apply Leave</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-purple/50 hover:bg-neon-purple/5 transition-all duration-300 group">
              <FileText className="w-8 h-8 text-secondary-400 group-hover:text-neon-purple mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">View Payslip</p>
            </button>
            <button 
              onClick={() => window.location.href = '/employee/tasks'}
              className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-pink/50 hover:bg-neon-pink/5 transition-all duration-300 group"
            >
              <Target className="w-8 h-8 text-secondary-400 group-hover:text-neon-pink mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">View Tasks</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-purple/50 hover:bg-neon-purple/5 transition-all duration-300 group">
              <User className="w-8 h-8 text-secondary-400 group-hover:text-neon-purple mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">Update Profile</p>
            </button>
          </div>
        </div>
      </div>
    </EmployeeLayout>
  );
};

export default EmployeeDashboard;