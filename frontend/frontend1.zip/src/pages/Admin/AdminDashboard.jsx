import React, { useEffect, useState } from 'react';
import AdminLayout from '../../components/Admin/AdminLayout/AdminLayout';
import { Users, Building2, Calendar, TrendingUp, Clock, UserCheck, Award } from 'lucide-react';
import toast from 'react-hot-toast';

// API utility function
import { dashboardAPI } from '../../utils/api';

const AdminDashboard = () => {
  const [stats, setStats] = useState([]);
  const [recentActivities, setRecentActivities] = useState([]);
  const [upcomingEvents, setUpcomingEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch all dashboard data
        const [statsResponse, activitiesResponse, eventsResponse] = await Promise.all([
          dashboardAPI.getAdminStats(),
          dashboardAPI.getRecentActivities(),
          dashboardAPI.getUpcomingEvents()
        ]);

        // Process stats data
        if (statsResponse.data.success) {
          const data = statsResponse.data;
          const statsArray = [
            {
              title: "Total Employees",
              value: data.totalEmployees || 0,
              icon: Users,
              color: "from-pink-500 to-purple-500",
              // change: "+5%",
              changeType: "positive"
            },
            {
              title: "Active Employees", 
              value: data.activeEmployees || 0,
              icon: UserCheck,
              color: "from-green-500 to-emerald-500",
              // change: "-2%",
              changeType: "negative"
            },
            {
              title: "Departments",
              value: data.departments || 0,
              icon: Building2,
              color: "from-blue-500 to-indigo-500",
              // change: "+1",
              changeType: "positive"
            },
            {
              title: "Leaves Today",
              value: data.leavesToday || 0,
              icon: Calendar,
              color: "from-yellow-500 to-orange-500",
              // change: "0%",
              changeType: "neutral"
            }
          ];
          setStats(statsArray);
        }

        // Process activities data
        if (activitiesResponse.data.success) {
          setRecentActivities(activitiesResponse.data.activities || []);
        }

        // Process events data
        if (eventsResponse.data.success) {
          setUpcomingEvents(eventsResponse.data.events || []);
        }

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error(error.response?.data?.message || 'Failed to load dashboard data');
        
        // Set default stats on error
        setStats([
          { title: "Total Employees", value: 0, icon: Users, color: "from-pink-500 to-purple-500", change: "+0%", changeType: "neutral" },
          { title: "Active Employees", value: 0, icon: UserCheck, color: "from-green-500 to-emerald-500", change: "+0%", changeType: "neutral" },
          { title: "Departments", value: 0, icon: Building2, color: "from-blue-500 to-indigo-500", change: "+0", changeType: "neutral" },
          { title: "Leaves Today", value: 0, icon: Calendar, color: "from-yellow-500 to-orange-500", change: "0%", changeType: "neutral" }
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-white text-xl">Loading dashboard...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Welcome Section */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Welcome back, <span className="neon-text">Admin!</span>
              </h1>
              <p className="text-secondary-400">Here's what's happening in your company today.</p>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-secondary-400">Today's Date</p>
                <p className="text-lg font-semibold text-white">
                  {new Date().toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="glass-morphism neon-border rounded-2xl p-6 hover-glow">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-gradient-to-r ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                  stat.changeType === 'positive' 
                    ? 'text-green-400 bg-green-400/10' 
                    : stat.changeType === 'negative'
                    ? 'text-red-400 bg-red-400/10'
                    : 'text-gray-400 bg-gray-400/10'
                }`}>
                  {stat.change}
                </span>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white mb-1">{stat.value}</h3>
                <p className="text-secondary-400 text-sm">{stat.title}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Activities */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Recent Activities</h2>
              <Clock className="w-5 h-5 text-neon-pink" />
            </div>
            <div className="space-y-4">
              {recentActivities.length > 0 ? (
                recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-secondary-700/30 transition-colors">
                    <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                      activity.type === 'success' ? 'bg-green-400' :
                      activity.type === 'warning' ? 'bg-yellow-400' : 'bg-blue-400'
                    }`}></div>
                    <div className="flex-1">
                      <p className="text-white text-sm">{activity.action}</p>
                      <p className="text-neon-pink text-sm font-medium">{activity.user}</p>
                      <p className="text-secondary-400 text-xs">{activity.time}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-secondary-400">No recent activities</p>
                </div>
              )}
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Upcoming Events</h2>
              <Calendar className="w-5 h-5 text-neon-purple" />
            </div>
            <div className="space-y-4">
              {upcomingEvents.length > 0 ? (
                upcomingEvents.map((event) => (
                  <div key={event.id} className="p-4 rounded-lg border border-secondary-600 hover:border-neon-pink/30 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-white font-medium">{event.title}</h4>
                      <span className="text-xs px-2 py-1 bg-neon-purple/20 text-neon-purple rounded-full">
                        {event.department}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-secondary-400">
                      <span>{new Date(event.date).toLocaleDateString()}</span>
                      <span>{event.time}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-secondary-400">No upcoming events</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <h2 className="text-xl font-bold text-white mb-6">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button 
              onClick={() => window.location.href = '/admin/employees'}
              className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-pink/50 hover:bg-neon-pink/5 transition-all duration-300 group"
            >
              <Users className="w-8 h-8 text-secondary-400 group-hover:text-neon-pink mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">Manage Employees</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-purple/50 hover:bg-neon-purple/5 transition-all duration-300 group">
              <Calendar className="w-8 h-8 text-secondary-400 group-hover:text-neon-purple mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">Leave Management</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-pink/50 hover:bg-neon-pink/5 transition-all duration-300 group">
              <TrendingUp className="w-8 h-8 text-secondary-400 group-hover:text-neon-pink mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">View Reports</p>
            </button>
            <button className="p-4 rounded-lg border-2 border-dashed border-secondary-600 hover:border-neon-purple/50 hover:bg-neon-purple/5 transition-all duration-300 group">
              <Award className="w-8 h-8 text-secondary-400 group-hover:text-neon-purple mx-auto mb-2" />
              <p className="text-sm text-secondary-400 group-hover:text-white">Task Management</p>
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;