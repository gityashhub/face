import React, { useState, useEffect } from 'react';
import { employeeAPI } from '../../utils/api'; // Use centralized API
import AdminLayout from '../../components/Admin/AdminLayout/AdminLayout';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Eye, 
  Trash2, 
  Mail, 
  Phone, 
  MapPin,
  User,
  X,
  Save,
  UserPlus
} from 'lucide-react';
import toast from 'react-hot-toast';

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [newEmployee, setNewEmployee] = useState({
    personalInfo: {
      firstName: '',
      lastName: '',
      dateOfBirth: '',
      gender: '',
      nationality: 'Indian',
      maritalStatus: 'Single',
      bloodGroup: ''
    },
    contactInfo: {
      phone: '',
      alternatePhone: '',
      personalEmail: '',
      address: {
        street: '',
        city: '',
        state: '',
        pincode: '',
        country: 'India'
      },
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      }
    },
    workInfo: {
      position: '',
      department: '',
      joiningDate: new Date().toISOString().split('T')[0],
      employmentType: 'Full-time',
      workLocation: 'Office',
      team: '',
      skills: [],
      workShift: 'Morning'
    },
    salaryInfo: {
      basicSalary: 0,
      allowances: {
        hra: 0,
        medical: 0,
        transport: 0,
        other: 0
      },
      deductions: {
        pf: 0,
        esi: 0,
        tax: 0,
        other: 0
      },
      currency: 'INR',
      payFrequency: 'Monthly'
    },
    bankInfo: {
      accountHolderName: '',
      accountNumber: '',
      bankName: '',
      branchName: '',
      ifscCode: '',
      accountType: 'Savings'
    }
  });

  const departments = ['Engineering', 'Product', 'Design', 'HR', 'Marketing', 'Sales', 'Finance', 'Operations'];
  const genders = ['Male', 'Female', 'Other'];
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const maritalStatuses = ['Single', 'Married', 'Divorced', 'Widowed'];
  const employmentTypes = ['Full-time', 'Part-time', 'Contract', 'Intern'];
  const workLocations = ['Office', 'Remote', 'Hybrid'];
  const workShifts = ['Morning', 'Afternoon', 'Evening', 'Night', 'Flexible'];
  const accountTypes = ['Savings', 'Current'];

  // Fetch employees from backend using centralized API
  const fetchEmployees = async () => {
    try {
      setLoading(true);
      console.log('Fetching employees...');
      
      const response = await employeeAPI.getEmployees();
      console.log('Employee API Response:', response.data);
      
      if (response.data.success) {
        const employeeData = response.data.data?.employees || [];
        console.log('Setting employees:', employeeData.length, 'employees');
        setEmployees(employeeData);
      } else {
        console.error('API returned success: false');
        toast.error('Failed to fetch employees');
      }
    } catch (error) {
      console.error('Error fetching employees:', error);
      
      // Better error handling
      if (error.response?.status === 401) {
        toast.error('Session expired. Please login again.');
        // Let the API interceptor handle the redirect
      } else if (error.response?.status === 403) {
        toast.error('Access denied. You don\'t have permission to view employees.');
      } else if (error.response?.data?.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Failed to fetch employees. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const filteredEmployees = employees.filter(emp => {
    const fullName = `${emp.personalInfo?.firstName || ''} ${emp.personalInfo?.lastName || ''}`.toLowerCase();
    const userEmail = emp.user?.email?.toLowerCase() || '';
    const position = emp.workInfo?.position?.toLowerCase() || '';
    const employeeId = emp.employeeId?.toLowerCase() || emp.user?.employeeId?.toLowerCase() || '';
    
    const matchesSearch = fullName.includes(searchTerm.toLowerCase()) ||
                         userEmail.includes(searchTerm.toLowerCase()) ||
                         position.includes(searchTerm.toLowerCase()) ||
                         employeeId.includes(searchTerm.toLowerCase());
    
    const matchesDepartment = !filterDepartment || emp.workInfo?.department === filterDepartment;
    return matchesSearch && matchesDepartment;
  });

  const handleAddEmployee = async (e) => {
    e.preventDefault();
    
    try {
      console.log('Creating employee with data:', newEmployee);
      
      const response = await employeeAPI.createEmployee(newEmployee);
      console.log('Create employee response:', response.data);
      
      if (response.data.success) {
        await fetchEmployees(); // Refresh the list
        resetNewEmployeeForm();
        setShowAddModal(false);
        
        const employeeName = `${newEmployee.personalInfo.firstName} ${newEmployee.personalInfo.lastName}`;
        toast.success(`Employee ${employeeName} added successfully! Login credentials sent via email.`);
      }
    } catch (error) {
      console.error('Error adding employee:', error);
      
      if (error.response?.data?.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Failed to add employee. Please try again.');
      }
    }
  };

  const resetNewEmployeeForm = () => {
    setNewEmployee({
      personalInfo: {
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        gender: '',
        nationality: 'Indian',
        maritalStatus: 'Single',
        bloodGroup: ''
      },
      contactInfo: {
        phone: '',
        alternatePhone: '',
        personalEmail: '',
        address: {
          street: '',
          city: '',
          state: '',
          pincode: '',
          country: 'India'
        },
        emergencyContact: {
          name: '',
          relationship: '',
          phone: ''
        }
      },
      workInfo: {
        position: '',
        department: '',
        joiningDate: new Date().toISOString().split('T')[0],
        employmentType: 'Full-time',
        workLocation: 'Office',
        team: '',
        skills: [],
        workShift: 'Morning'
      },
      salaryInfo: {
        basicSalary: 0,
        allowances: {
          hra: 0,
          medical: 0,
          transport: 0,
          other: 0
        },
        deductions: {
          pf: 0,
          esi: 0,
          tax: 0,
          other: 0
        },
        currency: 'INR',
        payFrequency: 'Monthly'
      },
      bankInfo: {
        accountHolderName: '',
        accountNumber: '',
        bankName: '',
        branchName: '',
        ifscCode: '',
        accountType: 'Savings'
      }
    });
  };

  const handleEditEmployee = async (e) => {
    e.preventDefault();
    
    try {
      console.log('Updating employee:', selectedEmployee._id);
      
      const response = await employeeAPI.updateEmployee(selectedEmployee._id, selectedEmployee);
      console.log('Update employee response:', response.data);
      
      if (response.data.success) {
        await fetchEmployees(); // Refresh the list
        setShowEditModal(false);
        toast.success('Employee updated successfully!');
      }
    } catch (error) {
      console.error('Error updating employee:', error);
      
      if (error.response?.data?.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error('Failed to update employee. Please try again.');
      }
    }
  };

  const handleDeleteEmployee = async (id) => {
    if (window.confirm('Are you sure you want to delete this employee? This will also delete their user account.')) {
      try {
        console.log('Deleting employee:', id);
        
        const response = await employeeAPI.deleteEmployee(id);
        console.log('Delete employee response:', response.data);
        
        if (response.data.success) {
          await fetchEmployees(); // Refresh the list
          toast.success('Employee deleted successfully!');
        }
      } catch (error) {
        console.error('Error deleting employee:', error);
        
        if (error.response?.data?.message) {
          toast.error(error.response.data.message);
        } else {
          toast.error('Failed to delete employee. Please try again.');
        }
      }
    }
  };

  const ViewModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 neon-border rounded-2xl p-6 w-full max-w-6xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Employee Details</h2>
          <button 
            onClick={() => setShowViewModal(false)}
            className="text-secondary-400 hover:text-white"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        {selectedEmployee && (
          <div className="space-y-6">
            {/* Profile Section */}
            <div className="flex items-center space-x-4 p-4 bg-secondary-800/30 rounded-lg">
              <div className="w-16 h-16 bg-gradient-to-r from-neon-pink to-neon-purple rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{selectedEmployee.fullName}</h3>
                <p className="text-neon-pink">{selectedEmployee.workInfo?.position}</p>
                <p className="text-secondary-400">{selectedEmployee.workInfo?.department}</p>
                <p className="text-secondary-400 text-sm">ID: {selectedEmployee.employeeId || selectedEmployee.user?.employeeId}</p>
              </div>
            </div>

            {/* Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Personal Info */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Personal Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-secondary-400">Full Name</label>
                    <p className="text-white">{selectedEmployee.fullName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Date of Birth</label>
                    <p className="text-white">
                      {selectedEmployee.personalInfo?.dateOfBirth ? 
                        new Date(selectedEmployee.personalInfo.dateOfBirth).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Age</label>
                    <p className="text-white">{selectedEmployee.age || 'N/A'} years</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Gender</label>
                    <p className="text-white">{selectedEmployee.personalInfo?.gender || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Blood Group</label>
                    <p className="text-white">{selectedEmployee.personalInfo?.bloodGroup || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Marital Status</label>
                    <p className="text-white">{selectedEmployee.personalInfo?.maritalStatus || 'N/A'}</p>
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Contact Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-secondary-400">Email</label>
                    <p className="text-white">{selectedEmployee.user?.email || selectedEmployee.contactInfo?.personalEmail}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Phone</label>
                    <p className="text-white">{selectedEmployee.contactInfo?.phone}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Alternate Phone</label>
                    <p className="text-white">{selectedEmployee.contactInfo?.alternatePhone || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Address</label>
                    <p className="text-white text-sm">
                      {selectedEmployee.contactInfo?.address?.street && (
                        <>
                          {selectedEmployee.contactInfo.address.street}<br/>
                          {selectedEmployee.contactInfo.address.city}, {selectedEmployee.contactInfo.address.state}<br/>
                          {selectedEmployee.contactInfo.address.pincode}, {selectedEmployee.contactInfo.address.country}
                        </>
                      ) || 'N/A'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Emergency Contact</label>
                    <p className="text-white text-sm">
                      {selectedEmployee.contactInfo?.emergencyContact?.name && (
                        <>
                          {selectedEmployee.contactInfo.emergencyContact.name} ({selectedEmployee.contactInfo.emergencyContact.relationship})<br/>
                          {selectedEmployee.contactInfo.emergencyContact.phone}
                        </>
                      ) || 'N/A'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Work Info */}
              <div className="space-y-4">
                <h4 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Work Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-secondary-400">Department</label>
                    <p className="text-white">{selectedEmployee.workInfo?.department}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Position</label>
                    <p className="text-white">{selectedEmployee.workInfo?.position}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Join Date</label>
                    <p className="text-white">
                      {selectedEmployee.workInfo?.joiningDate ? 
                        new Date(selectedEmployee.workInfo.joiningDate).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Years of Service</label>
                    <p className="text-white">{selectedEmployee.yearsOfService || 0} years</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Employment Type</label>
                    <p className="text-white">{selectedEmployee.workInfo?.employmentType || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Work Location</label>
                    <p className="text-white">{selectedEmployee.workInfo?.workLocation || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Team</label>
                    <p className="text-white">{selectedEmployee.workInfo?.team || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Work Shift</label>
                    <p className="text-white">{selectedEmployee.workInfo?.workShift || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Basic Salary</label>
                    <p className="text-white">
                      {selectedEmployee.salaryInfo?.currency} {selectedEmployee.salaryInfo?.basicSalary?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Gross Salary</label>
                    <p className="text-white">
                      {selectedEmployee.salaryInfo?.currency} {selectedEmployee.grossSalary?.toLocaleString() || '0'}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-secondary-400">Status</label>
                    <span className="inline-block px-2 py-1 text-xs rounded-full bg-green-400/20 text-green-400">
                      {selectedEmployee.status || 'Active'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Skills */}
            {selectedEmployee.workInfo?.skills && selectedEmployee.workInfo.skills.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-lg font-bold text-white">Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedEmployee.workInfo.skills.map((skill, index) => (
                    <span key={index} className="px-3 py-1 bg-neon-pink/20 text-neon-pink rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );

  const AddEditModal = ({ isEdit = false }) => {
    const employee = isEdit ? selectedEmployee : newEmployee;
    
    const updateEmployee = (field, value, nestedField = null, subNestedField = null) => {
      if (isEdit) {
        if (subNestedField) {
          setSelectedEmployee({
            ...selectedEmployee,
            [field]: {
              ...selectedEmployee[field],
              [nestedField]: {
                ...selectedEmployee[field][nestedField],
                [subNestedField]: value
              }
            }
          });
        } else if (nestedField) {
          setSelectedEmployee({
            ...selectedEmployee,
            [field]: {
              ...selectedEmployee[field],
              [nestedField]: value
            }
          });
        } else {
          setSelectedEmployee({
            ...selectedEmployee,
            [field]: value
          });
        }
      } else {
        if (subNestedField) {
          setNewEmployee({
            ...newEmployee,
            [field]: {
              ...newEmployee[field],
              [nestedField]: {
                ...newEmployee[field][nestedField],
                [subNestedField]: value
              }
            }
          });
        } else if (nestedField) {
          setNewEmployee({
            ...newEmployee,
            [field]: {
              ...newEmployee[field],
              [nestedField]: value
            }
          });
        } else {
          setNewEmployee({
            ...newEmployee,
            [field]: value
          });
        }
      }
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-gray-900 neon-border rounded-2xl p-6 w-full max-w-6xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white">
              {isEdit ? 'Edit Employee' : 'Add New Employee'}
            </h2>
            <button 
              onClick={() => isEdit ? setShowEditModal(false) : setShowAddModal(false)}
              className="text-secondary-400 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={isEdit ? handleEditEmployee : handleAddEmployee} className="space-y-8">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">First Name *</label>
                  <input
                    type="text"
                    value={employee.personalInfo?.firstName || ''}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'firstName')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Last Name *</label>
                  <input
                    type="text"
                    value={employee.personalInfo?.lastName || ''}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'lastName')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Date of Birth *</label>
                  <input
                    type="date"
                    value={employee.personalInfo?.dateOfBirth ? employee.personalInfo.dateOfBirth.split('T')[0] : ''}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'dateOfBirth')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Gender *</label>
                  <select
                    value={employee.personalInfo?.gender || ''}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'gender')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  >
                    <option value="">Select Gender</option>
                    {genders.map(gender => (
                      <option key={gender} value={gender}>{gender}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Blood Group</label>
                  <select
                    value={employee.personalInfo?.bloodGroup || ''}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'bloodGroup')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    <option value="">Select Blood Group</option>
                    {bloodGroups.map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Marital Status</label>
                  <select
                    value={employee.personalInfo?.maritalStatus || 'Single'}
                    onChange={(e) => updateEmployee('personalInfo', e.target.value, 'maritalStatus')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    {maritalStatuses.map(status => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Contact Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Email *</label>
                  <input
                    type="email"
                    value={employee.contactInfo?.personalEmail || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'personalEmail')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Phone *</label>
                  <input
                    type="tel"
                    value={employee.contactInfo?.phone || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'phone')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Alternate Phone</label>
                  <input
                    type="tel"
                    value={employee.contactInfo?.alternatePhone || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'alternatePhone')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Street Address</label>
                  <input
                    type="text"
                    value={employee.contactInfo?.address?.street || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'address', 'street')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">City</label>
                  <input
                    type="text"
                    value={employee.contactInfo?.address?.city || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'address', 'city')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">State</label>
                  <input
                    type="text"
                    value={employee.contactInfo?.address?.state || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'address', 'state')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Pincode</label>
                  <input
                    type="text"
                    value={employee.contactInfo?.address?.pincode || ''}
                    onChange={(e) => updateEmployee('contactInfo', e.target.value, 'address', 'pincode')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div className="md:col-span-2">
                  <h4 className="text-md font-semibold text-white mb-3">Emergency Contact</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-secondary-300 mb-2">Name *</label>
                      <input
                        type="text"
                        value={employee.contactInfo?.emergencyContact?.name || ''}
                        onChange={(e) => updateEmployee('contactInfo', e.target.value, 'emergencyContact', 'name')}
                        className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-secondary-300 mb-2">Relationship *</label>
                      <input
                        type="text"
                        value={employee.contactInfo?.emergencyContact?.relationship || ''}
                        onChange={(e) => updateEmployee('contactInfo', e.target.value, 'emergencyContact', 'relationship')}
                        className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-secondary-300 mb-2">Phone *</label>
                      <input
                        type="tel"
                        value={employee.contactInfo?.emergencyContact?.phone || ''}
                        onChange={(e) => updateEmployee('contactInfo', e.target.value, 'emergencyContact', 'phone')}
                        className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Work Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Work Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Position *</label>
                  <input
                    type="text"
                    value={employee.workInfo?.position || ''}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'position')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Department *</label>
                  <select
                    value={employee.workInfo?.department || ''}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'department')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Joining Date *</label>
                  <input
                    type="date"
                    value={employee.workInfo?.joiningDate ? employee.workInfo.joiningDate.split('T')[0] : ''}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'joiningDate')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Employment Type</label>
                  <select
                    value={employee.workInfo?.employmentType || 'Full-time'}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'employmentType')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    {employmentTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Work Location</label>
                  <select
                    value={employee.workInfo?.workLocation || 'Office'}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'workLocation')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    {workLocations.map(location => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Work Shift</label>
                  <select
                    value={employee.workInfo?.workShift || 'Morning'}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'workShift')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    {workShifts.map(shift => (
                      <option key={shift} value={shift}>{shift}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Team</label>
                  <input
                    type="text"
                    value={employee.workInfo?.team || ''}
                    onChange={(e) => updateEmployee('workInfo', e.target.value, 'team')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
              </div>
            </div>

            {/* Salary Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Salary Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Basic Salary *</label>
                  <input
                    type="number"
                    value={employee.salaryInfo?.basicSalary || ''}
                    onChange={(e) => updateEmployee('salaryInfo', parseFloat(e.target.value) || 0, 'basicSalary')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    required
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">HRA</label>
                  <input
                    type="number"
                    value={employee.salaryInfo?.allowances?.hra || ''}
                    onChange={(e) => updateEmployee('salaryInfo', parseFloat(e.target.value) || 0, 'allowances', 'hra')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Medical Allowance</label>
                  <input
                    type="number"
                    value={employee.salaryInfo?.allowances?.medical || ''}
                    onChange={(e) => updateEmployee('salaryInfo', parseFloat(e.target.value) || 0, 'allowances', 'medical')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    min="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Transport Allowance</label>
                  <input
                    type="number"
                    value={employee.salaryInfo?.allowances?.transport || ''}
                    onChange={(e) => updateEmployee('salaryInfo', parseFloat(e.target.value) || 0, 'allowances', 'transport')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                    min="0"
                  />
                </div>
              </div>
            </div>

            {/* Bank Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-secondary-600 pb-2">Bank Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Account Holder Name</label>
                  <input
                    type="text"
                    value={employee.bankInfo?.accountHolderName || ''}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'accountHolderName')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Account Number</label>
                  <input
                    type="text"
                    value={employee.bankInfo?.accountNumber || ''}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'accountNumber')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Bank Name</label>
                  <input
                    type="text"
                    value={employee.bankInfo?.bankName || ''}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'bankName')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Branch Name</label>
                  <input
                    type="text"
                    value={employee.bankInfo?.branchName || ''}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'branchName')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">IFSC Code</label>
                  <input
                    type="text"
                    value={employee.bankInfo?.ifscCode || ''}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'ifscCode')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-secondary-300 mb-2">Account Type</label>
                  <select
                    value={employee.bankInfo?.accountType || 'Savings'}
                    onChange={(e) => updateEmployee('bankInfo', e.target.value, 'accountType')}
                    className="w-full px-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
                  >
                    {accountTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 pt-6 border-t border-secondary-600">
              <button
                type="button"
                onClick={() => isEdit ? setShowEditModal(false) : setShowAddModal(false)}
                className="px-6 py-3 border border-secondary-600 text-secondary-300 rounded-lg hover:bg-secondary-700/50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-purple text-white font-semibold rounded-lg hover-glow transition-all duration-300"
              >
                <Save className="w-4 h-4 mr-2 inline" />
                {isEdit ? 'Update Employee' : 'Add Employee'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-white text-xl">Loading employees...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">Employee Management</h1>
            <p className="text-secondary-400">Manage your company's workforce</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-6 py-3 bg-gradient-to-r from-neon-pink to-neon-purple text-white font-semibold rounded-lg hover-glow transition-all duration-300 flex items-center"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Employee
          </button>
        </div>

        {/* Filters */}
        <div className="glass-morphism neon-border rounded-2xl p-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-secondary-400" />
              <input
                type="text"
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white placeholder-secondary-500 focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
              />
            </div>

            {/* Department Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-secondary-400" />
              <select
                value={filterDepartment}
                onChange={(e) => setFilterDepartment(e.target.value)}
                className="pl-10 pr-8 py-3 bg-secondary-800/50 border border-secondary-600 rounded-lg text-white focus:border-neon-pink focus:ring-2 focus:ring-neon-pink/20"
              >
                <option value="">All Departments</option>
                {departments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Employee Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">{employees.length}</h3>
                <p className="text-secondary-400">Total Employees</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">
                  {new Set(employees.map(e => e.workInfo?.department).filter(Boolean)).size}
                </h3>
                <p className="text-secondary-400">Departments</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                <UserPlus className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">
                  {employees.filter(e => e.status === 'Active' || !e.status).length}
                </h3>
                <p className="text-secondary-400">Active Employees</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                <UserPlus className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="glass-morphism neon-border rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white">
                  {employees.filter(e => {
                    const joinDate = new Date(e.workInfo?.joiningDate);
                    const thirtyDaysAgo = new Date();
                    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                    return joinDate >= thirtyDaysAgo;
                  }).length}
                </h3>
                <p className="text-secondary-400">New Joinings</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-pink-600 rounded-lg flex items-center justify-center">
                <UserPlus className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Employee Table */}
        <div className="glass-morphism neon-border rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-secondary-700">
                <tr>
                  <th className="text-left p-6 text-secondary-300 font-medium">Employee</th>
                  <th className="text-left p-6 text-secondary-300 font-medium">Position</th>
                  <th className="text-left p-6 text-secondary-300 font-medium">Department</th>
                  <th className="text-left p-6 text-secondary-300 font-medium">Join Date</th>
                  <th className="text-left p-6 text-secondary-300 font-medium">Status</th>
                  <th className="text-left p-6 text-secondary-300 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((employee) => (
                  <tr key={employee._id} className="border-b border-secondary-800 hover:bg-secondary-800/30 transition-colors">
                    <td className="p-6">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-neon-pink to-neon-purple rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-white font-medium">{employee.fullName}</p>
                          <p className="text-secondary-400 text-sm flex items-center">
                            <Mail className="w-3 h-3 mr-1" />
                            {employee.user?.email || employee.contactInfo?.personalEmail}
                          </p>
                          <p className="text-secondary-400 text-xs">ID: {employee.employeeId || employee.user?.employeeId}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-6 text-white">{employee.workInfo?.position}</td>
                    <td className="p-6">
                      <span className="px-3 py-1 text-xs rounded-full bg-secondary-700 text-secondary-300">
                        {employee.workInfo?.department}
                      </span>
                    </td>
                    <td className="p-6 text-secondary-400">
                      {employee.workInfo?.joiningDate ? 
                        new Date(employee.workInfo.joiningDate).toLocaleDateString() : 'N/A'}
                    </td>
                    <td className="p-6">
                      <span className={`px-3 py-1 text-xs rounded-full ${
                        employee.status === 'Active' || !employee.status
                          ? 'bg-green-400/20 text-green-400' 
                          : 'bg-red-400/20 text-red-400'
                      }`}>
                        {employee.status || 'Active'}
                      </span>
                    </td>
                    <td className="p-6">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => {
                            setSelectedEmployee(employee);
                            setShowViewModal(true);
                          }}
                          className="p-2 text-secondary-400 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setSelectedEmployee(employee);
                            setShowEditModal(true);
                          }}
                          className="p-2 text-secondary-400 hover:text-neon-pink hover:bg-neon-pink/10 rounded-lg transition-colors"
                          title="Edit"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteEmployee(employee._id)}
                          className="p-2 text-secondary-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredEmployees.length === 0 && (
            <div className="p-12 text-center">
              <User className="w-12 h-12 text-secondary-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-secondary-400 mb-2">No employees found</h3>
              <p className="text-secondary-500">
                {searchTerm || filterDepartment 
                  ? 'Try adjusting your search filters' 
                  : 'Start by adding your first employee'}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showAddModal && <AddEditModal />}
      {showEditModal && <AddEditModal isEdit />}
      {showViewModal && <ViewModal />}
    </AdminLayout>
  );
};

export default EmployeeManagement;