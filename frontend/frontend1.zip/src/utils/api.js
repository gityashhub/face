// utils/api.js - Updated version with the missing endpoint
import axios from 'axios';
import toast from 'react-hot-toast';

// Create axios instance with base URL
const API = axios.create({
  baseURL: 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Get token from storage (check both localStorage and sessionStorage)
const getToken = () => {
  return localStorage.getItem('token') || 
         sessionStorage.getItem('token') || 
         localStorage.getItem('authToken') || 
         sessionStorage.getItem('authToken');
};

// Get user role from storage
const getUserRole = () => {
  return localStorage.getItem('userRole') || 
         sessionStorage.getItem('userRole') || 
         localStorage.getItem('role') || 
         sessionStorage.getItem('role');
};

// Add auth token to requests
API.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    console.log('API Request:', {
      url: config.url,
      method: config.method,
      hasToken: !!token,
      token: token?.substring(0, 20) + '...'
    });
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Handle auth errors and responses
API.interceptors.response.use(
  (response) => {
    console.log('API Response:', {
      url: response.config.url,
      status: response.status,
      success: response.data?.success
    });
    return response;
  },
  (error) => {
    console.error('API Response Error:', {
      url: error.config?.url,
      status: error.response?.status,
      message: error.response?.data?.message
    });

    if (error.response?.status === 401) {
      console.log('Authentication failed, clearing storage and redirecting...');
      
      // Clear all auth data
      localStorage.removeItem('token');
      localStorage.removeItem('authToken');
      localStorage.removeItem('userRole');
      localStorage.removeItem('userEmail');
      localStorage.removeItem('userName');
      localStorage.removeItem('userId');
      localStorage.removeItem('employeeId');
      
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('authToken');
      sessionStorage.removeItem('userRole');
      sessionStorage.removeItem('userEmail');
      sessionStorage.removeItem('userName');
      sessionStorage.removeItem('userId');
      sessionStorage.removeItem('employeeId');
      
      // Redirect to login
      window.location.href = '/login';
      toast.error('Session expired. Please login again.');
    }
    
    return Promise.reject(error);
  }
);

// Dashboard API calls
export const dashboardAPI = {
  getAdminStats: () => API.get('/dashboard/stats'),
  getEmployeeStats: () => API.get('/dashboard/employee-stats'),
  getRecentActivities: () => API.get('/dashboard/activities'),
  getUpcomingEvents: () => API.get('/dashboard/events'),
  getDashboardSummary: () => API.get('/dashboard/summary')
};

// Employee API calls
export const employeeAPI = {
  createEmployee: (employeeData) => API.post('/employees', employeeData),
  getEmployees: (params = {}) => API.get('/employees', { params }),
  getEmployeeById: (id) => API.get(`/employees/${id}`),
  getMyProfile: () => API.get('/auth/me'), // UPDATED: Changed from '/employees/me' to '/auth/me'
  updateEmployee: (id, employeeData) => API.put(`/employees/${id}`, employeeData),
  deleteEmployee: (id) => API.delete(`/employees/${id}`),
  getEmployeeStats: () => API.get('/employees/stats'),
  getEmployeesByDepartment: (department) => API.get(`/employees/department/${department}`)
};

// Auth API calls
export const authAPI = {
  login: (loginData) => API.post('/auth/login', loginData),
  logout: () => API.post('/auth/logout'),
  getProfile: () => API.get('/auth/profile'),
  getMyProfile: () => API.get('/auth/me'), // ADDED: New endpoint for employee profile
  updateProfile: (profileData) => API.put('/auth/profile', profileData),
  changePassword: (passwordData) => API.put('/auth/change-password', passwordData),
  forgotPassword: (email) => API.post('/auth/forgot-password', { email }),
  resetPassword: (token, password) => API.put(`/auth/reset-password/${token}`, { password })
};

// Export the configured axios instance
export default API;