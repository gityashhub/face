import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import Sidebar from "../Siderbar/Sidebar";
import Header from "../Header/Header";

const AdminLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const sidebarItems = [
    { name: "Dashboard", path: "/admin/dashboard" },
    { name: "Employee Management", path: "/admin/employees" },
    { name: "Leave Management", path: "/admin/leaves" },
    { name: "Reports", path: "/admin/reports" },
    { name: "Settings", path: "/admin/settings" },
  ];

  const notifications = [
    { id: 1, message: "New employee registration request", time: "2 min ago", unread: true },
    { id: 2, message: "Leave request submitted by John Doe", time: "1 hour ago", unread: true },
    { id: 3, message: "Monthly report generated", time: "2 hours ago", unread: false },
  ];

  const handleLogout = () => {
    localStorage.removeItem("userRole");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("token");
    toast.success("Logged out successfully!");
    navigate("/login");
  };

  const unreadNotifications = notifications.filter((n) => n.unread).length;

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-secondary-900 via-secondary-800 to-secondary-900 relative">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      <div className="flex-1 flex flex-col lg:ml-64">
        <Header
          sidebarItems={sidebarItems}
          location={location}
          unreadNotifications={unreadNotifications}
          onLogout={handleLogout}
          setSidebarOpen={setSidebarOpen}
        />
        <main className="p-6 relative z-10">{children}</main>
      </div>
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default AdminLayout;
