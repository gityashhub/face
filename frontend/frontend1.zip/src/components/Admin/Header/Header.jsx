import React, { useState } from "react";
import { Menu, User, ChevronDown } from "lucide-react";
import NotificationBell from "./NotificationBell";
import ProfileDropdown from "./ProfileDropdown";

const Header = ({ sidebarItems, location, unreadNotifications, onLogout, setSidebarOpen }) => {
  const [profileDropdown, setProfileDropdown] = useState(false);

  return (
    <header className="bg-gray-900 border-b border-secondary-700 h-16 z-40 sticky top-0">
      <div className="flex items-center justify-between h-full px-6">
        {/* Mobile menu button */}
        <button
          onClick={() => setSidebarOpen(true)}
          className="lg:hidden text-secondary-400 hover:text-white"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Page Title */}
        <div className="hidden lg:block">
          <h2 className="text-xl font-semibold text-white">
            {sidebarItems.find((item) => item.path === location.pathname)?.name ||
              "Dashboard"}
          </h2>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          <NotificationBell unreadCount={unreadNotifications} />

          {/* Profile */}
          <div className="relative">
            <button
              onClick={() => setProfileDropdown(!profileDropdown)}
              className="flex items-center space-x-3 p-2 rounded-lg hover:bg-secondary-700/50 transition-colors"
            >
              <div className="w-8 h-8 bg-gradient-to-r from-neon-pink to-neon-purple rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-medium text-white">Admin User</p>
                <p className="text-xs text-secondary-400">admin@gmail.com</p>
              </div>
              <ChevronDown className="w-4 h-4 text-secondary-400" />
            </button>

            {profileDropdown && <ProfileDropdown onLogout={onLogout} />}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
