import React from "react";
import { Link } from "react-router-dom";
import { User, Settings, LogOut } from "lucide-react";

const ProfileDropdown = ({ onLogout }) => {
  return (
    <div className="absolute right-0 mt-2 w-48 glass-morphism rounded-lg border border-secondary-600 shadow-lg z-50">
      <div className="py-2">
        <Link
          to="/admin/profile"
          className="flex items-center px-4 py-2 text-sm text-secondary-300 hover:text-white hover:bg-secondary-700/50"
        >
          <User className="w-4 h-4 mr-3" />
          Profile Settings
        </Link>
        <Link
          to="/admin/settings"
          className="flex items-center px-4 py-2 text-sm text-secondary-300 hover:text-white hover:bg-secondary-700/50"
        >
          <Settings className="w-4 h-4 mr-3" />
          Settings
        </Link>
        <hr className="my-2 border-secondary-600" />
        <button
          onClick={onLogout}
          className="flex items-center w-full px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-secondary-700/50"
        >
          <LogOut className="w-4 h-4 mr-3" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default ProfileDropdown;
